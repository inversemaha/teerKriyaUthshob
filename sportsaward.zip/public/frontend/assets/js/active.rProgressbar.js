(function($) {
    'use strict';

    $('.html').rProgressbar({
        percentage: 80,
        fillBackgroundColor: '#AF0F15'
    });
    $('.html-01').rProgressbar({
        percentage: 60,
        fillBackgroundColor: '#AF0F15'
    });
    $('.html-02').rProgressbar({
        percentage: 70,
        fillBackgroundColor: '#AF0F15'
    });
})(jQuery);